# MyReads Project

This is an app to organize your books according to 3 categories:
1- Currently Reading
2- Want to Read 
3- Read 

you can search the data base for new books to lend and read 

## Installation 

All you need is to open your command promt and cd into the App location then enter:

- npm install

After it finishs installing all the dependencies enter the command:

- npm start 

and the application will start on host 3000 on your machine, enjoy ^_^